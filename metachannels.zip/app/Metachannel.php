<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Metachannel extends Model
{
    //
}
